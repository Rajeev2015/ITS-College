import axios from 'axios'
import React, { useEffect, useState } from 'react'
import "./dashboard.css"


export const Dashboard = () => {
  const [categoery, setCategoery] = useState([])

  const getAllCategoery = async () => {
    const cateData = await axios.get("http://localhost:4004/api/categories")
    console.log(cateData);
    
    setCategoery(cateData.data.categories)
    console.log(cateData.data);

  }

  useEffect(() => {
    getAllCategoery();
  }, [])

  return (
    <>
      <div className="container-fluid" style={{marginTop:"1%"}}>
        <div className="row">
          <div className="col-md-3">
            <ul className="list-group">
               <li className="list-group-item" style={{backgroundColor:"darkblue",color:"white"}}>Select Categoery</li>
               {
                categoery.map((c,i)=>
                      <li className="list-group-item">{c}</li>
                )
               }
          
            
            </ul>

          </div>
          <div className="col-md-9"></div>
        </div>
      </div>
    </>
  )
}
