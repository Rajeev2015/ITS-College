import axios from 'axios'
import React, { useEffect, useState } from 'react'
import "./dashboard.css"
const BASE_URL = import.meta.env.VITE_BASE_URL;

export const Dashboard = () => {
  const [categoery, setCategoery] = useState([])
  const [blog, setBlog] = useState([])

  const getAllCategoery = async () => {
    const cateData = await axios.get(`${BASE_URL}/api/categories`)
    console.log(cateData);

    setCategoery(cateData.data.categories)
    console.log(cateData.data);

  }

  const getAllBlogs = async () => {
    try {
      const blogRes = await axios.get(`${BASE_URL}/api/blogs/all`);
      console.log(blogRes);
      setBlog(blogRes.data.blogs)

    }
    catch (err) {
      console.log(err);

    }
  }


  const getDetailByCate = async (cate_name) => {
    // alert(cate_name)
    try {
      const cateRes = await axios.get(`${BASE_URL}/api/blogs/catedata/` + cate_name)
      setBlog(cateRes.data.blogs)
    }
    catch (err) {
      console.log(err);

    }

  }

  useEffect(() => {
    getAllCategoery();
    getAllBlogs();
  }, [])

  return (
    <>
      <div className="container-fluid" style={{ marginTop: "1%" }}>
        <div className="row">
          <div className="col-md-3">
            <ul className="list-group">
              <li className="list-group-item" style={{ backgroundColor: "darkblue", color: "white" }}>Select Categoery</li>
              {
                categoery.map((c, i) =>
                  <li key={i} className="list-group-item" onClick={() => { getDetailByCate(c) }}>{c}</li>
                )
              }


            </ul>

          </div>
          <div className="col-md-9">
            <div className="container-fluid my-1">
              <div className="row">
                {
                  blog.map((item, index) =>
                    <div className="col-md-4 p-1">
                      {/* Blog Card */}
                      <div className="card shadow-sm border-0 rounded-3">
                        <img
                          src={`${BASE_URL}/uploads/${item.images}`}
                          className="card-img-top rounded-top-3 dashbord_blog_image_height"
                          alt="Blog Image"
                        />
                        <div className="card-body">
                          {/* <h5 className="card-title" style={{textTransform:"capitalize"}}>{item.catename}</h5> */}
                          <h5 className="card-title" style={{ textTransform: "capitalize" }}>{item.blogtitle}</h5>
                          <p className="card-text text-muted">
                            {item.blogdescription.substring(0, 60)}
                          </p>
                          <a href="#" className="btn btn-primary btn-sm">
                            Read More
                          </a>
                        </div>
                        <div className="card-footer text-muted small">
                          Posted on Sep {item.createdAt} by {item.blogauthor}
                        </div>
                      </div>
                    </div>
                  )
                }
              </div>
            </div>

          </div>
        </div>
      </div>
    </>
  )
}
