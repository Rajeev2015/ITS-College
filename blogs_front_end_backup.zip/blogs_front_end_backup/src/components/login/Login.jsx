import axios from 'axios'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'



export const Login = () => {
    const [user,setUser]=useState({
        username:'',
        password:''
    })

    const navigate=useNavigate()

    
    const handler=(e)=>{
        const {name,value}=e.target;
        setUser({...user,[name]:value})

    }
    const handleLogin=async(e)=>{
        e.preventDefault();
        console.log(user);
        try{
            const loginData=await axios.post("http://localhost:4004/api/login",user)
            console.log(loginData);
            if(loginData.data.success===true)
            {
                // console.log(loginData.data.token);
                localStorage.setItem("user_key",loginData.data.token)
                navigate("/")
            }
           
            
            
            

        }catch(err)
        {
            console.log(err);
            
        }
        

    }
    const goToSign=()=>{
        navigate("/sign-up")

    }
  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100">
            {/* <Toaster /> */}
            <div className="col-md-6 col-lg-5">
                <div className="card shadow p-4">
                    <h4 className="text-center mb-4">Login to Your Account</h4>
                    <form onSubmit={handleLogin}>
                        <div className="mb-3">
                            <label htmlFor="email" className="form-label">Email ID</label>
                            <input
                                type="text"
                                className="form-control"
                                name="username"
                                onChange={handler}
                                placeholder="Enter your email"
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="password" className="form-label">Password</label>
                            <input
                                type="password"
                                className="form-control"
                                name="password"
                                onChange={handler}
                                placeholder="Enter your password"
                            />
                        </div>
                        <div className="d-grid gap-2">
                            <button type="submit" className="btn btn-primary">
                                Login
                            </button>
                        </div>
                        <p className="form-text text-center mt-3">
                            Don't have an account? <a href="#" onClick={goToSign}>Sign Up</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
  )
}
