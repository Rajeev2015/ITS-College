import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'



export const Header = () => {
  const [status,setStatus]=useState(false)
  const naviagte=useNavigate();

  useEffect(()=>{
   if(localStorage.getItem('user_key'))
    {
      setStatus(true)
    }
  })

  const logout=()=>{
    localStorage.removeItem("user_key")
     naviagte("/")
     setStatus(false)
  }
  return (
    <nav
      className="navbar navbar-expand-lg"
      style={{ backgroundColor: "#001f4d" }}
    >
      <div className="container-fluid">
        <a className="navbar-brand text-white fw-bold" href="#">
          ITS College Blogs
        </a>
        <button
          className="navbar-toggler bg-light"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link className="nav-link text-white" to="/">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <a className="nav-link text-white" href="#">
                Blogs
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link text-white" href="#">
                About
              </a>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="contact-us">
                Contact
              </Link>
            </li>

            {
              status?
              (
                <>
                  <li className="nav-item dropdown">
                  <button
                    className="btn btn-danger dropdown-toggle"      /* red button, like old one */
                    id="userMenu"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Account
                  </button>

                  <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                    <li>
                      <button className="dropdown-item" >
                        ➕ Add Blog
                      </button>
                    </li>
                    <li>
                      <button className="dropdown-item"  >
                        📚 Blog List
                      </button>
                    </li>
                    <li><hr className="dropdown-divider" /></li>
                    <li>
                      <button className="dropdown-item text-danger" onClick={logout}>
                        🔓 Logout
                      </button>
                    </li>
                  </ul>
                </li>
                </>
              ):(
                <>
                   <li className="nav-item">
              <Link
                className="btn"
                style={{
                  backgroundColor: "#0d47a1",
                  color: "#fff",
                  marginRight: "10px",
                  fontWeight: "500"
                }}
                to="/login"
              >
                <i className="bi bi-box-arrow-in-right me-1"></i> Login
              </Link>
            </li>

            <li className="nav-item">
              <Link
                className="btn"
                style={{
                  backgroundColor: "#ff6f00", // vibrant orange
                  color: "#fff",
                  fontWeight: "600",
                  boxShadow: "0 4px 12px rgba(255, 111, 0, 0.4)",
                  borderRadius: "6px",
                  padding: "6px 16px",
                  transition: "all 0.3s ease"
                }}
                to="/sign-up"
              >
                <i className="bi bi-person-plus-fill me-1"></i> Register
              </Link>
            </li>
                </>
              )
            }



          </ul>
        </div>
      </div>
    </nav>
  )
}
