import axios from 'axios'
import React, { useEffect, useState } from 'react'
const BASE_URL = import.meta.env.VITE_BASE_URL;

export const Bloglist = () => {
    const [blogs, setblogs] = useState([])

    const getBlogList = async () => {
        try {
            // const blogList=await axios.get(`${BASE_URL}/api/blogs/blog-list`);
            // console.log(blogList);
            // setblogs(blogList.data.blogs)
            const token = localStorage.getItem("user_key");
            const blogList = await axios.get(`${BASE_URL}/api/blogs/blog-list`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            setblogs(blogList.data.blogs || [])
            //   console.log(res);

        }
        catch (err) {
            console.log(err);

        }
    }

    const deleteBlog = async (id) => {
        try {
            const confirmDelete = window.confirm("Are you sure you want to delete this blog?");
            if (!confirmDelete) return;

            try {
                const token = localStorage.getItem("user_key");
                await axios.delete(`${BASE_URL}/api/blogs/delete/${id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                toast.success("Blog deleted successfully");
                getBlogList(); // reload updated list
            } catch (error) {
                console.error(error);
                toast.error("Failed to delete blog");
            }
        }
        catch (err) {
            console.log(err);

        }
    }

    useEffect(() => {
        getBlogList();
    })

    return (
        <div className="container mt-4">
            <h3 className="mb-4">📚 My Blog List</h3>

            <div className="table-responsive">
                <table className="table table-bordered table-hover shadow rounded-4 overflow-hidden">
                    <thead className="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Blog Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {blogs.map((blog, index) => (
                            <tr key={blog._id}>
                                <td>{index + 1}</td>
                                <td>
                                    <img
                                        src={`${BASE_URL}/uploads/${blog.images}`}
                                        className="rounded"
                                        alt="Blog"
                                        width="80"
                                        height="60"
                                    />
                                </td>
                                <td>{blog.blogtitle}</td>
                                <td>{blog.blogauthor}</td>
                                <td width={380}>{blog.blogdescription.substring(0, 80)}</td>
                                <td>
                                    {/* <button className="btn btn-sm btn-warning me-2">✏️ Edit</button> */}
                                    <button
                                        className="btn btn-sm btn-danger"
                                        onClick={() => deleteBlog(blog._id)}
                                    >
                                        🗑️ Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {blogs.length === 0 && (
                            <tr>
                                <td colSpan="6" className="text-center">
                                    No blogs found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    )
}
