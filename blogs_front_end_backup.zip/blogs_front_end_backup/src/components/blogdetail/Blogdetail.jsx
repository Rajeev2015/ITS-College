import axios from 'axios'
import React, { useEffect, useState } from 'react'
import toast, { Toaster } from 'react-hot-toast';
import { useParams } from 'react-router-dom'
const BASE_URL = import.meta.env.VITE_BASE_URL;


export const Blogdetail = () => {
    const [blog, setBlog] = useState(null)

    const [comment, setComment] = useState();
    const [comments, setComments] = useState([]);

    const { id } = useParams();
    const getBlogBydId = async () => {
        try {
            const blogRes = await axios.get(`${BASE_URL}/api/blogs/blog-detail/` + id)
            // console.log(blogRes);
            setBlog(blogRes.data.blogs)

        }
        catch (err) {
            console.log(err);

        }
    }

    const getAllComments = async () => {
        try {
            const allCom = await axios.get(`${BASE_URL}/api/comment/all/` + id)
            console.log(allCom);
            setComments(allCom.data.comments)


        } catch (err) {
            console.log(err);

        }
    }


   


    const handleCommentSubmit = async (e) => {
        e.preventDefault();
        console.log(comment);
        try {
            const res = await axios.post(`${BASE_URL}/api/comment`, {
                commentText: comment.trim(),
                blog_id: id, // blog ID from URL
            });
            console.log(res);
            if (res.status === 201) {
                toast.success(res.data.message)
            }

        } catch (err) {
            console.log(err);

        }


    }
     useEffect(() => {
        getBlogBydId();
        getAllComments()
    }, [id])
    if (!blog) {
        return (
            <div className="container text-center py-5">
                <h4>⏳ Loading Blog Details...</h4>
            </div>
        );
    }
    return (
        <>
            <div className="container">
                <div className="row">
                    <Toaster />
                    <div className="col-md-12">
                        {/* <Toaster /> */}
                        <div
                            style={{
                                margin: "2% 2%",
                                fontSize: "25px",
                                textTransform: "uppercase",
                                fontWeight: "bold",
                            }}
                        >
                            Blog Details
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col-md-8">
                        <div className="card mb-3 shadow rounded-4 p-3">

                            <img
                                src={`${BASE_URL}/uploads/${blog.images}`}
                                className="rounded-3 single_blog_img_height"
                                alt="Blog Banner"
                            />


                            <div className="card-body">
                                <h3 className="card-title fw-bold" style={{ textTransform: "capitalize" }}>
                                    {blog.blogtitle}
                                </h3>

                                <p className="card-text" style={{ textAlign: "justify" }}>
                                    {blog.blogdescription}
                                </p>

                                <h5 className="mt-4">🖋 Blog Author: {blog.blogauthor}</h5>
                                <p className="card-text">
                                    <small className="text-muted">
                                        📅 Last updated on{" "}
                                        {new Date(blog.updatedAt).toLocaleDateString()} at{" "}
                                        {new Date(blog.updatedAt).toLocaleTimeString()}
                                    </small>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="row">
                    <div className="col-md-8">
                        <div className="card mt-4">
                            <div className="card-body">
                                <h5 className="card-title">💬 Leave a Comment</h5>
                                <form onSubmit={handleCommentSubmit}>
                                    <div className="mb-3">
                                        <textarea
                                            className="form-control"
                                            rows="3"
                                            // value={comment}
                                            placeholder="Write your comment here..."
                                            onChange={(e) => setComment(e.target.value)}
                                        ></textarea>
                                    </div>
                                    <button type="submit" className="btn btn-primary">
                                        Submit Comment
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>



                   <div className="card mt-4 shadow-sm">
                    <div className="card-body">
                        <h5 className="card-title">
                            🗨️ Comments ({comments.length})
                        </h5>

                        {comments.length === 0 ? (
                            <p className="text-muted">No comments yet. Be the first to comment!</p>
                        ) : (
                            <ul className="list-group list-group-flush">
                                {comments.map((cmt, index) => (
                                    <li key={index} className="list-group-item">
                                        <div>
                                            <p className="mb-1">{cmt.commentText}</p>
                                            <small className="text-muted">
                                                🕒 {new Date(cmt.createdAt).toLocaleString()}
                                            </small>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                </div>
            </div>






        </>
    )
}
