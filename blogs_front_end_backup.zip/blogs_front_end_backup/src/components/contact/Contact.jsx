import axios from 'axios'
import React, { useEffect, useState } from 'react'
import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom'
const BASE_URL = import.meta.env.VITE_BASE_URL;



export const Contact = () => {
  const [state, setState] = useState({
    name: '',
    phone: '',
    email: '',
    message: ''
  })


  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  }
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${BASE_URL}/api/contact`, state)
      console.log(res);
      if (res.status === 201) {
        toast.success(res.data.message)
      }

    } catch (err) {
      console.log(err);

    }
  }

  const _useNavigate = useNavigate()
  useEffect(() => {
    if (localStorage.getItem('user_key')) {

    }
    else {
      alert("You are not able to access this route !")
      _useNavigate("/login")

    }
  }, [])
  return (
    <div className="container mt-5" style={{ maxWidth: 650 }}>
      <h2 className="text-center mb-4">Contact Us</h2>
      <Toaster />
      <form type='submit' onSubmit={handleSubmit}>
        {/* Full Name */}
        <div className="mb-3">
          <label htmlFor="name" className="form-label">
            Full Name
          </label>
          <input
            type="text"
            className="form-control"
            id="name"
            name='name'

            onChange={handleChange}
            placeholder="Enter your full name"
            required=""
          />
        </div>
        {/* Email */}
        <div className="mb-3">
          <label htmlFor="email" className="form-label">
            Email Address
          </label>
          <input
            type="email"

            className="form-control"
            id="email"
            name='email'

            onChange={handleChange}
            placeholder="Enter your email"
            required=""
          />
        </div>
        {/* Phone */}
        <div className="mb-3">
          <label htmlFor="phone" className="form-label">
            Phone Number
          </label>
          <input
            type="tel"
            onChange={handleChange}
            name='phone'

            className="form-control"
            id="phone"

            placeholder="Enter your phone number"
          />
        </div>
        {/* Message */}
        <div className="mb-3">
          <label htmlFor="message" className="form-label">
            Your Message
          </label>
          <textarea
            className="form-control"
            id="message"
            rows={4}
            onChange={handleChange}
            name='message'

            placeholder="Type your message..."
            required=""
            defaultValue={""}
          />
        </div>
        {/* Submit */}
        <button type="submit" className="btn btn-primary w-100">
          Send Message
        </button>
      </form>
    </div>

  )
}
