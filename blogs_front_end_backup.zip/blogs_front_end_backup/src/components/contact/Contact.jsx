import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'



export const Contact = () => {
  const _useNavigate=useNavigate()
  useEffect(()=>{
     if(localStorage.getItem('user_key'))
    {
      
    }
    else 
    {
      alert("You are not able to access this route !")
      _useNavigate("/login")

    }
  },[])
  return (
    <div className='my_title'>Contact</div>
  )
}
