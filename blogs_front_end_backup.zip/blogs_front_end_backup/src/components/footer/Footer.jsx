import React from 'react'

export const Footer = () => {
  return (
    <>
  {/* Footer */}
  <footer
    className="text-white text-center py-4"
    style={{ backgroundColor: "#001f4d",marginTop:"5%" }}
  >
    <div className="container">
      <p className="mb-1 fw-bold">ITS College Blogs Project</p>
      <p className="mb-2">© 2025 ITS College | All Rights Reserved</p>
      {/* Footer Links */}
      <div>
        <a href="#" className="text-white text-decoration-none mx-2">
          Home
        </a>{" "}
        |
        <a href="#" className="text-white text-decoration-none mx-2">
          Blogs
        </a>{" "}
        |
        <a href="#" className="text-white text-decoration-none mx-2">
          About
        </a>{" "}
        |
        <a href="#" className="text-white text-decoration-none mx-2">
          Contact
        </a>
      </div>
    </div>
  </footer>
</>

  )
}
