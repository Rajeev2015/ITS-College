import React from 'react'
import "./pagenotfound.css"
import { Link } from 'react-router-dom'


export const Pagenotfound = () => {
  return (
    <div className="error-container">
  <div className="error-code">404</div>
  <div className="error-message">
    Oops! The page you are looking for was not found.
  </div>
  <Link to="/" className="btn btn-custom">
    Go Back Home
  </Link>
</div>

  )
}
