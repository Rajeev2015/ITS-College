import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Dashboard } from './components/dashboard/Dashboard'
import { BrowserRouter, Route,Routes } from 'react-router-dom'
import { Header } from './components/header/Header'
import { Footer } from './components/footer/Footer'
import { Pagenotfound } from './components/pagenotfound/Pagenotfound'
import { Contact } from './components/contact/Contact'
import { Signup } from './components/signup/Signup'
import { Login } from './components/login/Login'
import { Addblog } from './components/addblog/Addblog'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     <BrowserRouter>
          <Header/>
              <Routes>
                <Route path='/' element={<Dashboard/>}/>
                <Route path='contact-us' element={<Contact/>}/>
                <Route path='login' element={<Login/>}/>
                  <Route path='sign-up' element={<Signup/>}/>
                  <Route path='add-blog' element={<Addblog/>}/>
                <Route path='*' element={<Pagenotfound/>}/>
              </Routes>
          <Footer/>
     </BrowserRouter>
    </>
  )
}

export default App
