const express = require('express')
const router = express.Router()
const Comment = require("../models/Comment")

router.post("/", async (req, res) => {
    // console.log(req.params.id);
    //  console.log(req.body);
    try {
        const { blog_id, commentText } = req.body;

        if (!blog_id || !commentText) {
            return res.status(400).json({ msg: "All fields are required" });
        }

        const newComment = await Comment.create({ blog_id, commentText });

        res.status(201).json({ message: "Comment posted", comment: newComment });
    }
    catch (err) {
        console.log(err);

    }

})

// POST /api/comments
router.get("/all/:id", async (req, res) => {
  try {
    const comments = await Comment.find({ blog_id: req.params.id }).sort({ createdAt: -1 });
    res.status(200).json({ comments });
  } catch (err) {
    console.error("Error fetching comments:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});




module.exports = router;