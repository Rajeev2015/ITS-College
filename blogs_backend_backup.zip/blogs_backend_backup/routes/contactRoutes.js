const express = require('express')
const router = express.Router()
const Contact = require("../models/Contact")

router.post('/contact', async (req, res) => {
    try {
        console.log(req.body)
        const { name, email, phone, message } = req.body;
        const data = await Contact.create({ name, email, phone, message });

        return res.status(201).json({
            success: true,
            message: "Message Send  successfully!",
        });

    } catch (error) {
        console.log(error);

    }
})



module.exports = router;