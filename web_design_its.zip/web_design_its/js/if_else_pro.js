function evenOdd() {
    var num = parseInt(prompt("Enter the numbner : ?"))
    if (num % 2 == 0) {
        alert("It is even number : " + num)
    }
    else {
        alert("It is odd number : " + num)
    }

}

function maxTwo() {
    var a = parseInt(prompt("Enter the 1 numbner : ?"))
    var b = parseInt(prompt("Enter the 2 numbner : ?"))
    if (a > b) {
        alert("It is max number : " + a)
    }
    else {
        alert("It is max number : " + b)
    }
}

function maxThree() {
    var a = parseInt(prompt("Enter the 1 numbner : ?"))
    var b = parseInt(prompt("Enter the 2 numbner : ?"))
    var c = parseInt(prompt("Enter the 3 numbner : ?"))
    // if(a>b)
    // {
    //     if(a>c)
    //     {
    //         alert("It is max number : "+a)
    //     }
    //     else 
    //     {
    //         alert("It is max number : "+c)
    //     }
    // }
    // else if(b>c)
    // {
    //     alert("It is max number : "+b)
    // }
    // else 
    // {
    //     alert("It is max number : "+c)
    // }

    if (a > b && a > c) {
        alert("It is max number : " + a)
    }
    else if (b > a && b > c) {
        alert("It is max number : " + b)
    }
    else {
        alert("It is max number : " + c)
    }
}

function maxFour() {
    var a = parseInt(prompt("Enter the 1 numbner : ?"))
    var b = parseInt(prompt("Enter the 2 numbner : ?"))
    var c = parseInt(prompt("Enter the 3 numbner : ?"))
    var d = parseInt(prompt("Enter the 4 numbner : ?"))
    // if(a>b && a>c && a>d)
    // {
    //     alert("It is max number : "+a)
    // }
    // else if(b>a && b>c && b>d)
    // {
    //     alert("It is max number : "+b)
    // }
    // else if(c>a && c>b && c>d)
    // {
    //      alert("It is max number : "+c)
    // }
    // else 
    // {
    //      alert("It is max number : "+d)
    // }


    if (a > b) {
        if (a > c) {
            if (a > d) {
                alert("It is max number : " + a)
            }
            else {
                alert("It is max number : " + d)
            }
        }
        else if (c > d) {
            alert("It is max number : " + c)
        }
        else {
            alert("It is max number : " + d)
        }
    }
    else if (b > c) {
        if (b > d) {
            alert("It is max number : " + b)
        }
        else {
            alert("It is max number : " + d)
        }
    }
    else if (c > d) {
        alert("It is max number : " + c)
    }
    else {
        alert("It is max number : " + d)
    }

}

function printWeekday() {
    var day = parseInt(prompt("Enter the weekday number : ?"))
    if (day == 1) {
        15
        alert("Mon")
    }
    else if (day == 2) {
        15
        alert("Tue")
    }
    else if (day == 3) {
        15
        alert("Wed")
    }
    else if (day == 4) {
        15
        alert("Thu")
    }
    else if (day == 5) {
        15
        alert("Fri")
    }
    else if (day == 6) {
        15
        alert("Sat")
    }
    else if (day == 7) {
        15
        alert("Sunday")
    }
    else {
        alert("Invaliod Weekday number : " + day)
    }
}

function monthDay() {
    var month = parseInt(prompt("Enter the month number : ?"))
    // if(month==1)
    // {
    //     alert("31 days")
    // }
    // else  if(month==2)
    // {
    //     alert("28 days")
    // }
    //  else  if(month==3)
    // {
    //     alert("31 days")
    // }
    //  else  if(month==4)
    // {
    //     alert("30 days")
    // }
    //  else  if(month==5)
    // {
    //     alert("31 days")
    // }
    //  else  if(month==6)
    // {
    //     alert("30 days")
    // }
    //  else  if(month==7)
    // {
    //    alert("31 days")
    // }
    //  else  if(month==8)
    // {
    //     alert("31 days")
    // }
    //  else  if(month==9)
    // {
    //     alert("30 days")
    // }
    //  else  if(month==10)
    // {
    //     alert("31 days")
    // }
    //  else  if(month==11)
    // {
    //    alert("30 days")
    // }
    //  else  if(month==12)
    // {
    //     alert("31 days")
    // }
    // else 
    // {
    //     alert("Invalid Month Number : "+month)
    // }
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
        // alert("31 days ")
        if (month == 1) {
            alert("Jan 31 days")
        }
        else if (month == 3) {
            alert("Marc 31 days")
        }
        else if (month == 5) {
            alert("May 31 days")
        }
        else if (month == 7) {
            alert("July 31 days")
        }
        else if (month == 8) {
            alert("Aug 31 days")
        }
        else if (month == 10) {
            alert("Oct 31 days")
        }
        else {
            alert("Dec 31 days")
        }
    }
    else if (month == 4 || month == 6 || month == 9 || month == 11) {
        if (month == 4) {
            alert("Apr 31 days")
        }
        else if (month == 6) {
            alert("June 31 days")
        }
        else if (month == 9) {
            alert("Sep 31 days")
        }
        else {
            alert("Nov 31 days")
        }
    }
    else if (month == 2) {
        alert("28 days ")
    }
    else {
        alert("Invalid month number : " + month)
    }

}