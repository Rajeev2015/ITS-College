import {name,age} from './person.js';
import message from './message.js';
console.log(name+" "+age);

console.log(message());



