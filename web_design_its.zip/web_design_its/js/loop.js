// function whileLoop()
// {
//     var i=1;                             
//     while(i<=5)                         
//     {
//         document.writeln("<br/>"+i)         
                                        
//         i++; 
//     }
// }

// function dowhileLoop()
// {
//     var i=1;
//     do 
//     {
//         document.writeln("<br/>"+i)
//         i++
//     }while(i<=5);
// }

// function forLoop()
// {
//     for(var i=1;i<=5;i++)
//     {
//         document.writeln("<br/>"+i)
//     }
// }

// function exPrePost()
// {
//     // var x=10;
//     // document.writeln(x++)
//     // document.writeln("<br/>")
//     // document.writeln(x)

//     //  document.writeln(x--)
//     // document.writeln("<br/>")
//     // document.writeln(x)

//     //    document.writeln(++x)
//     // document.writeln("<br/>")
//     // document.writeln(x)
//     document.writeln("<br/>")
//     // document.writeln(x++ + --x)
//         // All => 0
//         // 
//     // document.writeln(--x - x++)
//                     //   9  - 9
//     // 28 => 7
//     // 27 => 1
//     // 29 => 1
//     // document.writeln(--x + ++x + --x);

//     // 82 => 3


//     // var x=82;

//     // document.writeln(x++ - x++ + x++);
                    


                    
// }
// table =12;

// for(let i =1; i<=10; i++){
//     console.log(table+"*"+i+"="+i*table);
  
// }

function tablePrint()
{
    var num=parseInt(prompt("Enter the table number :?"))
    // var i=1;
    // while(i<=10)
    // {
    //     document.writeln(num+"*"+i+"="+num*i+"<br/>")
    //     i++;
    // }

   
    // var i=1;
    // do 
    // {
    //     document.writeln(num+"*"+i+"="+num*i+"<br/>")
    //     i++;
    // }while(i<=10)

    for(var i=1;i<=10;i++)
    {
         document.writeln(num+"*"+i+"="+num*i+"<br/>")
    }
}

// Wap in js ask to user how many numbers do you want  and find all
// positive number
// negative number
// even number 
// odd number  ?

function findAll()
{
    var count=parseInt(prompt("How many numbers do you want : ?"))
    var i=1;
    var even=odd=pos=neg=0;
    while(i<=count)
    {
        // document.writeln(`Enter ${i} number : ?`)
        var data=parseInt(prompt(`Enter ${i} Number : ?`))
        if(data>0)
        {
            pos++;
        }
        else
        {
            neg++
        }
        if(data%2==0)
        {
            even++
        }
        else 
        {
            odd++
        }
        i++
    }
    document.writeln("<br/> Total postive number is : "+pos)
    document.writeln("<br/> Total negative number is : "+neg)
    document.writeln("<br/> Total even number is : "+even)
    document.writeln("<br/> Total odd number is : "+odd)
}