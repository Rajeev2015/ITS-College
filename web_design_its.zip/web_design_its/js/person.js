export const name = "Jesse";
export const age = 40;

// const name = "Jesse";
// const age = 40;

// export {name, age};