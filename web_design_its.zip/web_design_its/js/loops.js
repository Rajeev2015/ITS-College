function factNum()
{
    var num=parseInt(prompt("Enter the number : ?"))
    var fact=1;
    while(num>0)
    {
        fact=num*fact;
        num--;
    }
    // document.writeln("<br/> The Fact value is : "+fact)
    document.getElementById("result").innerHTML="The Fact value is : "+fact;
}