function marksCal() {
    var phy = parseInt(prompt("Enter the phy number : ?"))
    var che = parseInt(prompt("Enter the che number : ?"))
    var math = parseInt(prompt("Enter the math number : ?"))
    var total = phy + che + math;
    var avg = total / 3;
    // alert(avg)

    if (phy >= 30) {
        if (che >= 30) {
            if (math >= 30) {
                if (avg >= 0 && avg < 30) {
                    alert("Fail")
                }
                else if (avg >= 30 && avg < 45) {
                    alert("III Div")
                }
                else if (avg >= 45 && avg < 60) {
                    alert("II Div")
                }
                else if (avg >= 60 && avg <= 100) {
                    alert("I Div")
                }
            }
            else {
                alert("You are fail in math : " + math)
            }
        }
        else {
            alert("You are fail in che : " + che)
        }
    }
    else {
        alert("You are fail in phy : " + phy)
    }

}

function findVowel() {
    var choice = prompt("Enter the character : ?")
    // alert(choice.length)
    if (choice.length != 1) {
        alert("It is not a character ! " + choice)
    }
    else {
        // alert("else")
        if (choice >= 'a' && choice <= 'z') {
            if (choice == 'a' || choice == 'e' || choice == 'i' || choice == 'o' || choice == 'u') {
                alert("It is vowel : " + choice)
            }
            else {
                alert("It is consonenet : " + choice)
            }
        }
        if (choice >= 'A' && choice <= 'Z') {
            if (choice == 'A' || choice == 'E' || choice == 'I' || choice == 'O' || choice == 'U') {
                alert("It is vowel : " + choice)
            }
            else {
                alert("It is consonenet : " + choice)
            }
        }
        if (choice >= '0' && choice <= '9') {
            alert("It is digits : " + choice)
        }
        if (choice == " ") {
            alert("It is space : " + choice)
        }
        if (choice == "@") {
            alert("It is @ Symbol : " + choice)
        }
        if (choice == "&") {
            alert("It is & Symbol : " + choice)
        }
    }
    // if(choice=='a' || choice=='e'  || choice=='i'  || choice=='o'  || choice=='u' || choice=='A' || choice=='E'  || choice=='I'  || choice=='O'  || choice=='U')
    // {
    //     alert("It is vowel : "+choice)
    // }
    // else 
    // {
    //     alert("It is consonenet : "+choice)
    // }
}

function findVowel1() {
    var choice = prompt("Enter the character : ?")
    switch (choice) {
        case 'a':
        case 'A':
            alert("It is vowel : " + choice)
            break;
        case 'e':
        case 'E':
            alert("It is vowel : " + choice)
            break;
        case 'i':
        case 'I':
            alert("It is vowel : " + choice)
            break;
        case 'o':
        case 'O':
            alert("It is vowel : " + choice)
            break;
        case 'u':
        case 'U':
            alert("It is vowel : " + choice)
            break;
        default:
             alert("It is con : " + choice)
            break;

        


    }
}