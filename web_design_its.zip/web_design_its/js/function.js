function maxFind(number) {
    // console.log(number);

    var temp = number[0];
    for (var i = 0; i < number.length; i++) {
        if (number[i] >= temp) {
            temp = number[i]
        }
    }

    // document.writeln("<br/> Maxvalue is : " + temp)
    return temp

}
// var num = [10, 20, 500, 40, 30];
// document.writeln(maxFind(num))
// document.writeln("<br/>")

// var num1 = [10, 20, 500, 40, 30, 455, 45, 454, 534, 543, 5345, 345, 545];
// document.writeln(maxFind(num1))
// document.writeln("<br/>")

// var num2 = [10, 20, 500, 40, 30, 2313, 23, 232, 32, 344, 34, 343, 43, 434, 343, 43, 434, 343, 434, 343434, 4344];
// var res=maxFind(num2);
// document.writeln("<br/>"+res)
// var sum=res+100;
// document.writeln("<br/>"+sum)

function sumAll(p_list)
{
    var sum=0;
    for(i=0;i<p_list.length;i++)
    {
        sum+=p_list[i]
    }
    return sum;
}

var product_list=[10,20,30,40,50];
document.writeln(sumAll(product_list))


