function maxFind() {
    var products = [10, 20, 30, 50, 5, 40, 66, 55];
    //    document.writeln("<br/>"+products[2]+" "+products[4])
    //    for(var i=0;i<5;i++)
    //    {
    //     document.writeln("["+i+"]="+products[i]+"<br/>")
    //    }
    var temp = products[0];
    for (var i = 0; i < products.length; i++) {
        // document.writeln("<br/>"+products[i])
        if (products[i] <= temp) {
            temp = products[i]
        }
    }
    document.writeln("<br/> max value is : " + temp)
}

function sumAll() {
    var products = [10, 20, 30, 40, 50, 60, 70];
    var sum = 0;
    for (var i = 0; i < products.length; i++) {

        sum = sum + products[i];
        // document.writeln("<br/>"+products[i])
    }
    document.writeln("Total sum of price is" + sum)
}

function searchData() {
    var nameList = Array("rajeev", "rajesh", "ravi", "ranjeet", "rupesh", "ravi", "krishna", "ravi", "sumit", "mohan")
    //  var nameList=Array("rajeev","rajesh","ravi","ranjeet");
    var name = prompt("Enter the name : ?")
    var temp = false
    var count = 0
    for (var i = 0; i < nameList.length; i++) {
        // document.writeln("<br/>"+nameList[i])
        if (nameList[i] == name) {
            // document.writeln("<br/> Name is found : "+name)
            // break;
            count++;
            temp = true
        }
        // else 
        // {
        //      document.writeln("<br/> Name is not found : "+name)
        //      break
        // }
    }

    if (temp == true) {
        if (count == 1) {
            document.writeln("<br/> Name is found : " + name)
        }
        else {
            document.writeln("<br/>" + name + " name is " + count + " Times found.")
        }

    }
    else {
        document.writeln("<br/> Name is not found : " + name)
    }

}

function bookListUpdate() {
    var bookList = ["html", "css", "javascript", "php", "react", "mongodb", "node", "java", "python"];
    var old_name = prompt("Enter the old book name : ?")
    var temp = 0;
    for (var i = 0; i < bookList.length; i++) {
        if (bookList[i] == old_name) {
            var new_name = prompt("Enter the  new book name : ?")
            bookList[i] = new_name
            temp = 1;
            break;

        }
    }
    if (temp == 0) {
        alert("Your Book Name is not found : ! " + old_name)
    }
    else {
        for (var i = 0; i < bookList.length; i++) {
            document.writeln("<br/>" + bookList[i])
        }
    }


}

function reverseOrder() {
    var bookList = ["html", "css", "javascript", "php", "react"];
    var newBookList = [];
    //  for(var i=0;i<bookList.length;i++)
    //  {
    //     document.writeln("<br/>"+bookList[i])
    //  }
    for (var i = bookList.length - 1, j = 0; i >= 0; i--, j++) {
        // document.writeln("<br/>"+bookList[i])
        newBookList[j] = bookList[i]
    }
    // document.writeln("<br/>"+newBookList)
    for (var i = 0; i < newBookList.length; i++) {
        document.writeln("<br/>" + newBookList[i])
    }

}

function loginSystem() {
    var userName = ["sumit", "sonu", "Sanjeev"];
    var userPass = ["sumit@123", "sonu@123", "Sanjeev@123"];
    var temp = false
    var user = prompt("Enter the username e: ?")
    var pass = prompt("Enter the password e: ?")

    for (var i = 0; i < userName.length; i++) {

        if (userName[i] === user && userPass[i] === pass) {
            
            temp = true
        }
    }
    if (temp == true) {
        alert("Login successfully !")
    }
    else {
        alert("Login Not successfully !")
    }
}