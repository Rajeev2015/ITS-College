import React, { Component } from 'react'
import "./dashboard.css"
import Card from './Card'
import Mycard from './Mycard'
import CardState from './CardState'

export default class Dashboard extends Component {
  render() {
    return (
      <>
        <div className="my_title">Dashbord</div>
        <div style={{display:"flex"}}>
          <Card p_name="shirt"  p_img="gallery/banner01.jpg" p_price="1200" p_desc="a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt" />
          <Card p_name="shirt" p_img="gallery/banner02.jpg" p_price="1200" p_desc="a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt" />
          <Card p_name="shirt" p_img="gallery/banner03.jpg" p_price="1200" p_desc="a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt" />
          <Card p_name="shirt" p_img="gallery/banner04.jpg" p_price="1200" p_desc="a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt" />
        </div>
        <Mycard/>
        <br /><br />
        <CardState/>
      </>
    )
  }
}
