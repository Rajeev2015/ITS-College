import React, { Component } from 'react'

export default class Mycard extends Component {
    constructor() {
        super();
        this.state = { count: 0 }
        console.log("cons");
        
    }
    increment = () => {
        this.setState({ count: this.state.count + 1 })

    }
    decrement = () => {
        this.setState({ count: this.state.count - 1 })
    }
    render() {
        return (
           
            <>
             {console.log("render")
            }
                <div style={{ textAlign: "center" }}>
                    {this.state.count}
                    <br />
                    <input type="submit" value="Increment" onClick={this.increment} />
                    &nbsp;
                    <input type="submit" value="Decrement" onClick={this.decrement} />
                </div>
            </>
        )
    }
}
