import React, { Component } from 'react'

export default class Card extends Component {
    constructor(props) {
        super(props);
        // console.log("con");
        // console.log(this.props);
        // console.log(this.props.p_img)


    }
    render() {
        const {p_name,p_img,p_price,p_desc}=this.props; // object detsructing
       
        return (
            <div>
                {/* <div className="card" style={{ width: "100%%" }}>
                    <img src={this.props.p_img} className="card-img-top my_product" alt="..." />
                    <div className="card-body">
                        <h5 className="card-title">{this.props.p_name}</h5>
                         <h5 className="card-title">{this.props.p_price}</h5>
                        <p className="card-text">
                           {this.props.p_desc}
                        </p>
                        <a href="#" className="btn btn-primary">
                            Go somewhere
                        </a>
                    </div>
                </div> */}
                 <div className="card" style={{ width: "100%%" }}>
                    <img src={p_img} className="card-img-top my_product" alt="..." />
                    <div className="card-body">
                        <h5 className="card-title">{p_name}</h5>
                         <h5 className="card-title">{p_price}</h5>
                        <p className="card-text">
                           {p_desc}
                        </p>
                        <a href="#" className="btn btn-primary">
                            Go somewhere
                        </a>
                    </div>
                </div>

            </div>
        )
    }
}
