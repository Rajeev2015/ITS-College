import React, { Component } from 'react'

export default class CardState extends Component {
    constructor() {
        super();
        this.state = [
            {
                p_name: "shirt",
                p_price: 2000,
                p_desc: "a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt",
                p_img: "gallery/banner01.jpg"
            },
            {
                p_name: "shirt",
                p_price: 2000,
                p_desc: "a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt",
                p_img: "gallery/banner02.jpg"
            },
            {
                p_name: "shirt",
                p_price: 2000,
                p_desc: "a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt",
                p_img: "gallery/banner03.jpg"
            },
            {
                p_name: "shirt",
                p_price: 2000,
                p_desc: "a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt",
                p_img: "gallery/banner04.jpg"
            },
              {
                p_name: "shirt",
                p_price: 2000,
                p_desc: "a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt",
                p_img: "gallery/banner05.jpg"
            },
            {
                p_name: "shirt",
                p_price: 2000,
                p_desc: "a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt",
                p_img: "gallery/banner06.jpg"
            },
            {
                p_name: "shirt",
                p_price: 2000,
                p_desc: "a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt",
                p_img: "gallery/banner07.jpg"
            },
            {
                p_name: "shirt",
                p_price: 2000,
                p_desc: "a garment for the upper part of the body usually with a collar, sleeves, a front opening, and a tail long enough to be tucked inside pants or a skirt",
                p_img: "gallery/banner08.jpg"
            }
        ]
        console.log(this.state);

    }
    render() {
        return (
            <>
                <div className="my_title">Prodcuts</div>
                <div className="container">
                    <div className="row">
                        {
                            this.state.map((data, index) =>
                                <div className="col-md-3">
                                    <div className="card" style={{ width: "100%",marginTop:"10px" }}>
                                        <img src={data.p_img} className="card-img-top my_product" alt="..." />
                                        <div className="card-body">
                                            <h5 className="card-title">{data.p_name}</h5>
                                              <h5 className="card-title">{data.p_price}</h5>
                                            <p className="card-text">
                                              {data.p_desc}
                                            </p>
                                            <a href="#" className="btn btn-primary">
                                                Go somewhere
                                            </a>
                                        </div>
                                    </div>

                                </div>

                            )
                        }
                    </div>
                </div>
            </>
        )
    }
}
