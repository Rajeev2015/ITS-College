import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div style={{height:"300px",marginTop:"5%",backgroundColor:"darkblue",color:"white"}}>Footer</div>
    )
  }
}
