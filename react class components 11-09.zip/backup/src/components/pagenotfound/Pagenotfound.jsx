import React, { Component } from 'react'

export default class Pagenotfound extends Component {
  render() {
    return (
      <div>Pagenotfound</div>
    )
  }
}
