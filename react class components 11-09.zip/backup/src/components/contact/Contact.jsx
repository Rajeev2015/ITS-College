import axios from 'axios';
import React, { Component } from 'react'

export default class Contact extends Component {
  constructor() {
    super();
    this.state = {
      f_name: '',
      l_name: '',
      email_id: '',
      mobile_number: '',
      message: '',
      msg:''
    }
  }

  setFname = (event) => {
    // console.log(event);
    // console.log(event.target);
    console.log(event.target.value);
    this.setState({ f_name: event.target.value })

  }
  setLname = (e) => {
    this.setState({ l_name: e.target.value })

  }
  setEmail = (e) => {
    this.setState({ email_id: e.target.value })

  }
  setMobile = (e) => {
    this.setState({ mobile_number: e.target.value })
  }
  setMessage = (e) => {
    this.setState({ message: e.target.value })
  }

  submitForm=(e)=>{
    e.preventDefault();
    // console.log(this.state);
    axios.post("http://localhost:3004/contact",this.state)
    .then((res)=>{
      // console.log(res);
      if(res.status===200 || res.status===201)
      {
        this.setState({msg:"Message send successfully !"})
      }
      
    })
    
  }

  render() {
    return (
      <>
        <div className="my_title">Contact</div>
        <div className="container">
          <div className="row">
            <div className="col-md-3"></div>
            <div className="col-md-6">
              {
                this.state.msg?(
                  <div className='alert alert-success'>{this.state.msg}</div>
                ):''
              }
              <form action="" onSubmit={this.submitForm}>
                <>
                  <div className="mb-3">
                    <label htmlFor="formGroupExampleInput" className="form-label">
                      First Name
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      name='f_name'
                      onChange={this.setFname}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="formGroupExampleInput2" className="form-label">
                      Last name
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      name='l_name'
                      onChange={this.setLname}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="formGroupExampleInput" className="form-label">
                      Email id
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      name='email_id'
                      onChange={this.setEmail}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="formGroupExampleInput2" className="form-label">
                      Mobile Number
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      name='mobile_number'
                      onChange={this.setMobile}
                    />
                  </div>
                </>

                <div className="mb-3">
                  <label htmlFor="formGroupExampleInput" className="form-label">
                    Message
                  </label>
                  <textarea name='message' onChange={this.setMessage} className='form-control' style={{ height: "80px" }} id=""></textarea>
                </div>
                <div className="mb-3">
                  <div style={{ textAlign: "center" }}>
                    <input type="submit" value="Send Message" className='btn btn-success' />
                  </div>
                </div>

              </form>
            </div>
            <div className="col-md-3"></div>
          </div>
        </div>
      </>
    )
  }
}
