import axios from 'axios';
import React, { Component } from 'react'


export default class About extends Component {
  constructor() {
    super();
    this.state = { mystore: [] }
  }
  getLiveData = () => {
    axios.get("https://jsonplaceholder.typicode.com/posts")
      .then((res) => {
        // console.log(res);
        console.log(res.data);

        this.setState({ mystore: res.data })

      })


  }
  render() {
    return (
      <div>
        <div className="my_title">About</div>
        <div style={{ textAlign: "center" }}>
          <input type="submit" value="Get Live Data" onClick={this.getLiveData} />
          <br />
          {/* <ul>
            {
              this.state.mystore.map((item,index)=>
                <li>{`User id is ${item.userId} and id is ${item.id} and Title is : ${item.title} and body is : ${item.body}`}</li>
              )
            }
          </ul> */}
          <table className="table table-hover">
             <thead>
              <tr>
                <th>User Id</th>
                <th>Id</th>
                <th>Title</th>
                <th>Body</th>
              </tr>
             </thead>
             <tbody>
            {
              this.state.mystore.map((v,i)=>
                  <tr key={i}>
                <td>{v.userId}</td>
                <td>{v.id}</td>
                <td>{v.title}</td>
                <td>{v.body}</td>
              </tr>
              )
            }
             </tbody>

          </table>
        </div>
      </div>
    )
  }
}
