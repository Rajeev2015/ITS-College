import axios from 'axios';
import React, { Component } from 'react'


export default class Contactlist extends Component {
    constructor()
    {
        super();
        this.state={mylist:[]}
    }
    contactList=()=>{
        axios.get("http://localhost:3004/contact")
        .then((res)=>{
            this.setState({mylist:res.data})
        })
    }
  render() {
    return (
      <>
      <div>Contactlist</div>
      <input type="submit" value="Contact List" onClick={this.contactList} />
         <table className="table table-hover">
             <thead>
              <tr>
                <th> Id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email Id</th>
                <th>Mobile Number</th>
                <th>Message</th>
              </tr>
             </thead>
             <tbody>
            {
              this.state.mylist.map((v,i)=>
                  <tr key={i}>
                <td>{v.id}</td>
                <td>{v.f_name}</td>
                <td>{v.l_name}</td>
                <td>{v.email_id}</td>
                <td>{v.mobile_number}</td>
                <td>{v.message}</td>
              </tr>
              )
            }
             </tbody>

          </table>
      </>
    )
  }
}
